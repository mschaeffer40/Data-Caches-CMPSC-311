#include "student.h"

int largest(int array[], int length) {

  int largest_number = array[0];

  for (int x = 1; x<length; x++)
      if (array[x] > largest_number)
      {
        largest_number = array[x];
      }
      


  return largest_number;
}

int sum(int array[], int length) {
  int x;
  int sum = 0;

  for (x = 0; x < length; x++)
  {
    sum = sum + array[x];
  }
  
  return sum;
}

void swap(int *a, int *b) {
  int t = *a;
  *a = *b;
  *b = t;


}

void rotate(int *a, int *b, int *c) {
  int t;
  t=*c;
  *c=*b;
  *b=*a;
  *a=t;
  
}

void sort(int array[], int length) {

  for (int i = 0; i < length-1; i++)
  {
    for (int j = 0; j < length-i-1; j++)
    {
      if (array[j]>array[j+1]){
        swap(&array[j],&array[j+1]);
      }
    }
    
  }
  

}
void double_primes(int array[], int length) {
  
  for (int i = 0; i < length; i++)
  {
    int num=array[i];
    if (num <= 1){
      continue;
    }
    else if (num == 2){
      array[i] = num *2;
      continue;
    }
    int is_prime = 1;
    for (int j = 2; j < num; j++){
      if (num % j == 0){
        is_prime = 0;
        break;
      }    
    }
    if (is_prime){
      array[i] = num * 2;
    }
  }
}
  
    

int power(int base, int exp){
  int result = 1;
  for (int i = 0; i < exp; i++)
  {
    result *= base;
  }
  return result;
}
int num_digits(int num){
  int count = 0;
  while (num!=0){
    num /=10;
    count++;
  }
  return count;
}

void negate_armstrongs(int array[], int length) {
  
  for (int i = 0; i < length; i++)
  {
    int num = array[i];
    int new_num = num;
    int rem = 0;
    int sum = 0;
    int digits = num_digits(num);

    if (num < 0)
    {
      continue;
    }
    
    if (num < 10)
    {
      array[i]*= -1;
      continue;
    }
    
    while (new_num !=0){
    
     rem = new_num%10;
     sum += power(rem,digits);
     new_num /= 10;
     
    }
    if (num == sum){
      array[i]*=-1;
    }
  }
  

  
}
