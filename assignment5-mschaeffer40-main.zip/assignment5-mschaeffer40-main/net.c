#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <err.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include "net.h"
#include "jbod.h"

/* the client socket descriptor for the connection to the server */
int cli_sd = -1;
struct sockaddr_in cadder;

/* attempts to read n bytes from fd; returns true on success and false on
 * failure */
static bool nread(int fd, int len, uint8_t *buf) {
  int n = 0;
  while (n < len)
  {
    int new_num = read(fd, buf+n, len-n);
    if(new_num == 0){
      return true;
    }
    if (new_num < 0)
    {
      return false;
    }
    n = n + new_num;

    
  }
  return true;
}

/* attempts to write n bytes to fd; returns true on success and false on
 * failure */
static bool nwrite(int fd, int len, uint8_t *buf) {
  int n = 0;
  while (n < len)
  {
    int new_num = write(fd, buf+n, len-n);
    if(new_num == 0){
      return true;
    }
    if (new_num < 0)
    {
      return false;
    }
    n = n + new_num;

    
  }
  return true;
}

/* attempts to receive a packet from fd; returns true on success and false on
 * failure */
static bool recv_packet(int fd, uint32_t *op, uint16_t *ret, uint8_t *block) {
  
  uint16_t ret_return;
  uint32_t op_return;
  uint16_t len;
  uint8_t head[HEADER_LEN];
  

  if(!nread(fd, HEADER_LEN,head)){
    return false;
  }


  int offset = 0;
  memcpy(&len, head, sizeof(len));
  offset += sizeof(len);
  uint16_t pkt = ntohs(len); 
  memcpy(&op_return, head + 2, sizeof(op_return));
  offset += sizeof(op_return);
  memcpy(&ret_return, head + 6, sizeof(ret_return));
  offset += sizeof(ret_return);

 
  *op = ntohl(op_return);
  *ret = ntohs(ret_return);

  if (pkt == HEADER_LEN + JBOD_BLOCK_SIZE)
  {
    bool net_read;
    net_read = nread(fd, JBOD_BLOCK_SIZE, block);
    if(!net_read){
      return false; 
    }
  }
  return true;
}

/* attempts to send a packet to sd; returns true on success and false on
 * failure */
static bool send_packet(int sd, uint32_t op, uint8_t *block) {
  uint32_t net_op = htonl(op);
  uint16_t size_of_packets = HEADER_LEN;
  jbod_cmd_t com = op >> 26;
  uint8_t buf[HEADER_LEN];


  bool write_pack = false;
  if(com == JBOD_WRITE_BLOCK){
    size_of_packets = HEADER_LEN+JBOD_BLOCK_SIZE;
    write_pack = true;
  }
  
  uint16_t netpkt_size = htons(size_of_packets);
  memcpy(buf, &netpkt_size, sizeof(size_of_packets));
  memcpy(buf+2, &net_op, sizeof(op));
  if(!nwrite(sd, HEADER_LEN, buf)){
    return false;
  }
  if(write_pack){
    bool net_write;
    net_write = nwrite(sd, JBOD_BLOCK_SIZE, block);
    if (!net_write)
    {
      return false;
    }
    
  }
  return true;


}

/* attempts to connect to server and set the global cli_sd variable to the
 * socket; returns true if successful and false if not. */
bool jbod_connect(const char *ip, uint16_t port) {
  int servers;
  servers = socket(PF_INET, SOCK_STREAM, 0);
  if(servers == -1){
    return -1;
  }
  cadder.sin_family = AF_INET;
  cadder.sin_port = htons(port);
  if (inet_aton(ip, &cadder.sin_addr) == 0)
  {
    return false;
  }
  if (connect(servers, (const struct sockaddr *)&cadder, sizeof(cadder)) == -1){
    return false;
  }
  cli_sd = servers;
  return true;
  


}

/* disconnects from the server and resets cli_sd */
void jbod_disconnect(void) {
  if(cli_sd != -1){
    close(cli_sd);
    cli_sd = -1;
  }
}

/* sends the JBOD operation to the server and receives and processes the
 * response. */
int jbod_client_operation(uint32_t op, uint8_t *block) {
  uint16_t recv_pkt;
  send_packet(cli_sd, op, block);
  recv_packet(cli_sd, &op, &recv_pkt, block);
  return recv_pkt;

}
