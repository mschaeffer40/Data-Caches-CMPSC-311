#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "cache.h"

static cache_entry_t *cache = NULL;
static int cache_size = 0;
static int clock = 0;
static int num_queries = 0;
static int num_hits = 0;
bool cache_check = false;

int cache_create(int num_entries) {
  if (num_entries < 2 || num_entries > 4096){
    return -1;
  }
  if (cache_check == true){
    return -1;
  }
  else{
  cache=(cache_entry_t*)calloc(num_entries,sizeof(cache_entry_t));
  cache_size = num_entries;
  cache_check = true;
  return 1;
  }
}

int cache_destroy(void) {
  if (cache_check == true){
    free(cache);
    cache = NULL;
    cache_size = 0;
    cache_check = false;
    return 1;
  }
  else{
    return -1;
  }
}

int cache_lookup(int disk_num, int block_num, uint8_t *buf) {
  bool check_empty = true;

  if (buf==NULL || cache == NULL || cache_size == 0 || cache_check == false){
    return -1;
  }
  for (int i = 0; i < cache_size; i++)
  {
    if (cache[i].valid){
      check_empty = false;
      break;
    }
  }
  if (check_empty == true){
    return -1;
  }
  num_queries++;

  for (int i = 0; i < cache_size; i++)
  {
    if (cache[i].disk_num == disk_num && cache[i].block_num == block_num && cache[i].valid)
    {
      memcpy(buf, &cache[i].block, JBOD_BLOCK_SIZE);
      num_hits++;
      clock++;
      num_queries++;
      cache[i].access_time=clock;
      return 1;
    }
    
  }
  return -1; 
}

void cache_update(int disk_num, int block_num, const uint8_t *buf) {
  for (int i = 0; i < cache_size; i++)
  {
    if (cache[i].disk_num == disk_num && cache[i].block_num == block_num)
    {
      memcpy(&cache[i].block, buf, JBOD_BLOCK_SIZE);
      clock++;
      cache[i].access_time=clock;
    }
    
  }
}

int cache_insert(int disk_num, int block_num, const uint8_t *buf) {
  bool full_cache = true;
  int empty_cache = 0;
  if (cache_check == false || buf == NULL || disk_num < 0 || block_num > JBOD_NUM_BLOCKS_PER_DISK - 1 || disk_num > JBOD_NUM_DISKS || block_num < 0)
  {
    return -1;
  }
  for (int i = 0; i < cache_size; i++)
  {
    if (!cache[i].valid)
    {
      full_cache = false;
      break;
    }
    empty_cache++;
    
  }
  if (full_cache)
  {
    int index = 0;
    int min = cache[0].access_time;
    for (int i = 0; i < cache_size; i++)
    {
      if (cache[i].access_time < min)
      {
        min = cache[i].access_time;
        index = i;
      }
      
    }
    for (int i = 0; i < cache_size; i++)
    {
      if(cache[i].block_num == block_num && cache[i].disk_num == disk_num && cache[i].valid == true){
        return -1;
      }
    }
    memcpy(&cache[index].block, buf, JBOD_BLOCK_SIZE);
    cache[index].block_num = block_num;
    cache[index].disk_num = disk_num;
    cache[index].valid = true;
    clock++;
    cache[index].access_time = clock;
    
  }
  else
  {
    memcpy(&cache[empty_cache].block, buf, JBOD_BLOCK_SIZE);
    cache[empty_cache].block_num = block_num;
    cache[empty_cache].disk_num = disk_num;
    cache[empty_cache].valid = true;
    clock++;
    cache[empty_cache].access_time = clock;
  }
  return 1;
}

bool cache_enabled(void) {
  if(cache_check == true){
    return true;
  }
  else{
    return false;
  }
}

void cache_print_hit_rate(void) {
  fprintf(stderr, "Hit rate: %5.1f%%\n", 100 * (float) num_hits / num_queries);
}
