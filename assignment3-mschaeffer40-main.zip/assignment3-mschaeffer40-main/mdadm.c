#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>

#include "mdadm.h"
#include "jbod.h"

uint32_t encode_operation(jbod_cmd_t cmd, int disk_num, int block_num){
  uint32_t operation = cmd << 26 | disk_num << 22 | block_num;
  return operation;

}

int mdadm_mount(void) {
  uint32_t jops = encode_operation(JBOD_MOUNT, 0, 0);
  int rc = jbod_operation(jops, NULL);
  if (rc==0)
  {
    return 1;
  }
  else{
    return -1;
  }
}

int mdadm_unmount(void) {
  uint32_t jops = encode_operation(JBOD_UNMOUNT, 0, 0);
  int rc = jbod_operation(jops, NULL);
  if (rc==0)
  {
    return 1;
  }
  else{
    return -1;
  }
}

void translate_address(uint32_t linear_addr, int *disk_num, int *block_num, int *offset){
  *disk_num = linear_addr / JBOD_DISK_SIZE;
  *block_num = (linear_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
  *offset = linear_addr % JBOD_DISK_SIZE % JBOD_BLOCK_SIZE;
}

int min(int x, int y){
  return x < y ? x : y;
}

int seek(int disk_num, int block_num){
  uint32_t op;
  int rc;
  op = encode_operation(JBOD_SEEK_TO_DISK, disk_num, 0);
  rc = jbod_operation(op, NULL);
  if (rc == -1) {
    return -1;
  }

  op = encode_operation(JBOD_SEEK_TO_BLOCK, 0, block_num);
  rc = jbod_operation(op, NULL);
  if (rc == -1) {
    return -1;
  }
  return 0;
}

int duplicate_data(uint8_t *external_buff, uint32_t len, int disk_num, int block_num, int offset){
  int rc = seek(disk_num, block_num);
  if (rc==-1)
  {
    return -1;
  }
  

  

  int disk_cross = 0;
  int curr_block;
  int cross_read = JBOD_NUM_BLOCKS_PER_DISK - (1024/JBOD_BLOCK_SIZE);
  if (block_num >= cross_read){
    int length_block = (len % JBOD_BLOCK_SIZE) ? len / JBOD_BLOCK_SIZE + 1 : len / JBOD_BLOCK_SIZE;
    int last_block = length_block + block_num;
    if (last_block > JBOD_NUM_BLOCKS_PER_DISK - 1)
    {
      curr_block = block_num;
      disk_cross = 1;
    }
  }
  uint8_t *internal_buf = malloc(JBOD_BLOCK_SIZE);
  memset(internal_buf,0,JBOD_BLOCK_SIZE);

  int bytes_left = len, bytes_read = 0;
  int bytes_to_read = min(len, JBOD_BLOCK_SIZE - offset);

  int first_read = 1;
  int count = 0;

  
  while (bytes_left > 0)
  {
    if (disk_cross && curr_block > JBOD_NUM_BLOCKS_PER_DISK - 1)
    {
      curr_block = 0;
      int rc = seek(disk_num + 1, curr_block);
      if (rc == -1)
      {
        free(internal_buf);
        return -1;
      }

      
    }
    uint32_t op = encode_operation(JBOD_READ_BLOCK, 0, 0);
    if (jbod_operation(op, internal_buf) == -1){
      free(internal_buf);
      return -1;
    }

    
    if (first_read)
    {
      memcpy(external_buff, internal_buf + offset, bytes_to_read);
      first_read = 0;
      
    }
    else{
      memcpy(external_buff + bytes_read, internal_buf, bytes_to_read);
      
    }
    memset(internal_buf, 0, JBOD_BLOCK_SIZE);

    bytes_left -= bytes_to_read;
    bytes_read += bytes_to_read;
    bytes_to_read = min(bytes_left, JBOD_BLOCK_SIZE);


    
    if (disk_cross){
      curr_block++;
    }

    
  }
  free(internal_buf);
  return len;
}
  



int mdadm_read(uint32_t addr, uint32_t len, uint8_t *buf) {
  int disk_num, block_num, offset;
  translate_address(addr, &disk_num, &block_num, &offset);
  if (len > 1024 || disk_num > JBOD_NUM_DISKS || block_num > JBOD_NUM_BLOCKS_PER_DISK || addr+ len > (JBOD_NUM_DISKS*JBOD_NUM_BLOCKS_PER_DISK*JBOD_BLOCK_SIZE))
  {
    return -1;
  }
  if (buf == NULL){
    if (len == 0){
      return len;
    }
    return -1;
  }
  return duplicate_data(buf, len, disk_num, block_num, offset);
}
int transfer_data(const uint8_t *buf, uint32_t len, int disk_num, int block_num, int offset){
  int rc = seek(disk_num, block_num);
  if (rc==-1)
  {
    return -1;
  }
  

  

  int disk_cross = 0;
  int curr_block = block_num;
  int curr_disk = disk_num;
  int cross_write = JBOD_NUM_BLOCKS_PER_DISK - (1024/JBOD_BLOCK_SIZE);
  if (block_num >= cross_write){
    int length_block = (len % JBOD_BLOCK_SIZE) ? len / JBOD_BLOCK_SIZE + 1 : len / JBOD_BLOCK_SIZE;
    int last_block = length_block + block_num;
    if (last_block > JBOD_NUM_BLOCKS_PER_DISK - 1)
    {
      disk_cross = 1;
    }
  }
  uint8_t *internal_buf = malloc(JBOD_BLOCK_SIZE);
  memset(internal_buf,0,JBOD_BLOCK_SIZE);

  int bytes_left = len, bytes_written = 0;
  int bytes_to_write = min(len, JBOD_BLOCK_SIZE - offset);

  int first_write = 1;
  int count = 0;

  
  while (bytes_left > 0)
  {
    if (disk_cross && curr_block > JBOD_NUM_BLOCKS_PER_DISK - 1)
    {
      curr_disk++;
      curr_block = 0;
      int rc = seek(curr_disk, curr_block);
      if (rc == -1)
      {
        free(internal_buf);
        return -1;
      }

      
    }
    if(bytes_to_write < JBOD_BLOCK_SIZE) {
      uint32_t op = encode_operation(JBOD_READ_BLOCK, 0, 0);
      if(jbod_operation(op, internal_buf) == -1) {
        free(internal_buf);
        return -1;
      }
      seek(curr_disk, curr_block);
    }

    if (first_write)
    {
      memcpy(internal_buf + offset,buf,bytes_to_write);
      first_write = 0;
      
    }
    else{
      memcpy(internal_buf,buf + bytes_written, bytes_to_write);
      
    }

    uint32_t op = encode_operation(JBOD_WRITE_BLOCK, 0, 0);
    if (jbod_operation(op, internal_buf) == -1){
      free(internal_buf);
      return -1;
    }
    
    memset(internal_buf, 0, JBOD_BLOCK_SIZE);

    bytes_left -= bytes_to_write;
    bytes_written += bytes_to_write;
    bytes_to_write = min(bytes_left, JBOD_BLOCK_SIZE);


    
  
    curr_block++;

    
  }
  free(internal_buf);
  return len;
}
int mdadm_write(uint32_t addr, uint32_t len, const uint8_t *buf) {
  int disk_num, block_num, offset;
  translate_address(addr, &disk_num, &block_num, &offset);
  if (len > 1024 || disk_num > JBOD_NUM_DISKS || block_num > JBOD_NUM_BLOCKS_PER_DISK || addr+ len > (JBOD_NUM_DISKS*JBOD_NUM_BLOCKS_PER_DISK*JBOD_BLOCK_SIZE))
  {
    return -1;
  }
  if (buf == NULL){
    if (len == 0){
      return len;
    }
    return -1;
  }
  return transfer_data(buf, len, disk_num, block_num, offset);
}
